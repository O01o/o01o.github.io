ここでは、プログラムを動作させるための環境構築の説明を行う。

予め、PHPとMAMP、Node.jsがインストールされていることを
確認されたい。

(1) Laravelのインストール
ターミナルに、以下のコマンドを入力する。
composer global require "laravel/installer"
続いて、任意のディレクトリにプロジェクトを展開する。
composer create-project laravel/laravel/ (プロジェクト名)

(2) データベースとの接続
プロジェクトのディレクトリ直下に、.envのファイルが
あることを確認する。次に、DBについて、以下の設定で
あることを確認する。指定先のデータベース名は後ほど
説明を行う。

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=8889
DB_DATABASE=(指定先のデータベース名)
DB_USERNAME=root
DB_PASSWORD=root
DB_SOCKET=/Applications/MAMP/tmp/mysql/mysql.sock

(3) phpMyAdminの起動確認, データベース設計
MAMPのアプリを立ち上げ、右上のボタンからサーバをstart
する。この時、PHPのバージョンやポート番号等に誤りが
無いかを事前に確認されたい。Google Chromeから、
以下のアドレスを入力する。
localhost:8888/phpMyAdmin
ここにアクセスすると、現在の自分のMySQLの状態をWeb
ブラウザから確認することができる。メニューからデータ
ベースの項目を選び、作成を行う。照合順序は
utf8_general_ciを選択する。

(4) テーブルの作成
テーブルの作成についてだが、これはphpMyAdminから
直接設定するのではなく、Laravelの方からマイグレーション
する。マイグレーションファイル自体は既に生成している
ので、そこから指定のデータベースにマイグレーションする。
php artisan migrate

(5) パッケージのインストール
続いて、必要なパッケージのインストールを行う。
composer require ramsay/uuid
composer require laravel/ui
php artisan ui vue --auth
npm install \&\& npm run dev
npm audit fix
npm run dev

(6) シンボリックリンクの設定
そして、シンボリックリンクを貼り付ける操作を行う。
これは画像一覧をWebからアクセスできるようにするために
必要である。
php artisan storage:link

(7) アプリを起動する
最後に、phpのアプリを起動するためのコマンドを入力する。
php artisan serve
これによって、localhost:8000からアプリに接続する
ことができる。また、Webサーバが起動している状態で
プログラムを変更しても、ページの再読み込みを行うことで
変更分が反映されるため、ターミナルは2つ準備しておく
ことを勧める。