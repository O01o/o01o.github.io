@extends('layouts.app')

@section('content')

<div class="card h-100">
    <div class="card-header">検索結果({{$category}}): {{$word}}</div>
        <div class="card-body">
            @if (session('status'))
                <div class="alert alert-success" role="alert">
                    {{ session('status') }}
                </div>
            @endif
            
            @if ($list == NULL)
                No Result
            @else
                <h2>検索結果一覧</h2>
                @if ($category == 'poster')
                    @foreach($list as $element)
                        <li><a href="/home/{{$element->poster}}">{{ $element->poster }}</a></li>
                    @endforeach
                @elseif ($category == 'series')
                    @foreach($list as $element)
                        <li><a href="/home/{{$element->poster}}/{{$element->series}}">{{ $element->series }}</a></li>
                    @endforeach
                @elseif ($category == 'content')
                    @foreach($list as $element)
                        <li><a href="/home/{{$element->poster}}/{{$element->series}}/{{$element->content}}">{{ $element->content }}</a></li>
                    @endforeach
                @else
                    恐らく条件が適切ではありません。
                @endif
            @endif
        </div>
    </div>
</div>
@endsection
