@extends('layouts.app')

@section('content')

<div class="card h-100">
    <div class="card-header">コンテンツ: {{$content}}（投稿者名: {{$user}}, シリーズ名: {{$series}}</div>
        <div class="card-body">
            @if (session('status'))
                <div class="alert alert-success" role="alert">
                    {{ session('status') }}
                </div>
            @endif

            @if ($file_list == NULL)
                No Result
            @else
                <h2>投稿コンテンツ</h2>
                @foreach($file_list as $file)
                    {{$file}}<br>
                    <img src="{{ asset('storage/'.$uuid.'/'.$file) }}" height="400px"></a><br>
                @endforeach
            @endif
        </div>
    </div>
</div>
@endsection
