@extends('layouts.auth')

@section('content')
<div class="container">
    <div class="card">
        <div class="card-header"> {{ $login_user['name'] }} さんの新規投稿 {{ $message = '' }}</div>
        <div class="card-body">
            <form method="POST" action="/store" enctype="multipart/form-data">
                @csrf
                <input type="file" name='file[]' value="" multiple accept="image/*">
                <input type="text" name="series" cols="30" rows="10" placeholder="シリーズ名">
                <input type="text" name="content" cols="30" rows="10" placeholder="コンテンツ名">
                
                <button type="submit" class="btn bun-primary btn-lg">保存</button>
            </form>
        </div>
    </div>
</div>
@endsection
