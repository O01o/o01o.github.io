@extends('layouts.app')

@section('content')

<div class="card h-100">
    <div class="card-header">{{ $user }} さんのページ</div>
        <div class="card-body">
            @if (session('status'))
                <div class="alert alert-success" role="alert">
                    {{ session('status') }}
                </div>
            @endif

            @if ($list_series == NULL)
                No Result
            @else
                <h2>投稿シリーズ</h2>
                @foreach($list_series as $series)
                    <li><a href="/home/{{$user}}/{{$series}}">{{ $series }}</a></li>
                @endforeach
            @endif
        </div>
    </div>
</div>
@endsection
