@extends('layouts.app')

@section('content')

<div class="card h-100">
    <div class="card-header">シリーズ: {{$series}} （投稿者名: {{$user}}）</div>
        <div class="card-body">
            @if (session('status'))
                <div class="alert alert-success" role="alert">
                    {{ session('status') }}
                </div>
            @endif

            @if ($list == NULL)
                No Result
            @else
                <h2>投稿コンテンツ</h2>
                @foreach($list as $element)
                    <li><a href="/home/{{$user}}/{{$series}}/{{$element->content}}">{{ $element->content }}</a></li>
                @endforeach
            @endif
        </div>
    </div>
</div>
@endsection
