@extends('layouts.auth')

@section('content')
<div class="container">
    <div class="card">
        <div class="card-header">{{ $login_user['name'] }} さんの新規投稿</div>
        <div class="card-body">
            {{ $message }}
            <a class='d-block' href='/home'>ホームへ</a>
        </div>
    </div>
</div>
@endsection
