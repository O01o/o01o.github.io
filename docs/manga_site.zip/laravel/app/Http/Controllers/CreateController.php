<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use App\Models\Contents;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Facades\Log;
use Illuminate\Routing\ResourceRegistrar;

class CreateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function create()
    {
        // ログイン変数をDBか参照
        $login_user = \Auth::user();
        return view('create', compact('login_user'));
    }

    public function store(Request $request) {
        // dd($request->file('file'));
        
        $access = True;
        $login_user = \Auth::user();
        $user = $login_user['name'];
        $uuid = Uuid::uuid4(); // ファイルを保存するパス
        
        $param = [
            'content' => $request->content,
            'series' => $request->series,
            'file' => $request->file('file')
        ];

        $content_object = Contents::where('poster', $user)
        ->where('series', $param['series'])
        ->where('content', $param['content'])
        ->first();

        $message = '';

        if ($content_object != NULL) { 
            $message = '投稿に失敗しました (※投稿作品が重複しています)';
            return view('done', compact('login_user', 'message'));
        } else if ($request->file('file') == NULL) {
            $message = '投稿に失敗しました (※ファイルが入力されてません)';
            return view('done', compact('login_user', 'message'));
        } else if ($request->series == NULL) {
            $message = '投稿に失敗しました (※シリーズが入力されてません)';
            return view('done', compact('login_user', 'message'));
        } else if ($request->content == NULL) {
            $message = '投稿に失敗しました (※コンテンツが入力されてません)';
            return view('done', compact('login_user', 'message'));
        } else {
            $message = '投稿が完了しました';

            // 投稿した画像ファイルを保存する
            foreach ($request->file('file') as $file) {
                $file_name = $file->getClientOriginalName();
                $file->storeAs('public/'.$uuid, $file_name);
            }

            // コンテンツテーブルに要素を追加する
            $new_content_object = Contents::create([
                'content' => $param['content'],
                'poster' => $login_user['name'],
                'series' => $param['series'],
                'access_enable' => True,
                'path' => $uuid,
                'created_at' => date("Y/m/d H:i:s"),
                'updated_at' => date("Y/m/d H:i:s"),
            ]);

            return view('done', compact('login_user', 'message'));
        }
    }
}
