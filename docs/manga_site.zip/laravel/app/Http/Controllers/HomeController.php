<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Contents;
use Illuminate\Validation\Rules\Unique;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function home_login_user()
    {
        $login_user = \Auth::user();
        $user = $login_user['name'];
        $list = Contents::where('poster', $user)->get();
        $list_series = [];
        foreach ($list as $element) {
            array_push($list_series, $element->series);
        }
        $list_series = array_unique($list_series);

        return view('home_user', compact('login_user', 'user', 'list_series'));
    }

    public function home_user($user)
    {
        $login_user = \Auth::user();
        $list = Contents::where('poster', $user)->get();
        $list_series = [];
        foreach ($list as $element) {
            array_push($list_series, $element->series);
        }
        $list_series = array_unique($list_series);

        return view('home_user', compact('login_user', 'user', 'list_series'));
    }

    public function home_series($user, $series)
    {
        $login_user = \Auth::user();
        $list = Contents::where('poster', $user)
            ->where('series', $series)
            ->get();

        return view('home_series', compact('login_user', 'user', 'series', 'list'));
    }

    public function home_content($user, $series, $content)
    {
        $login_user = \Auth::user();
        $content_object = Contents::where('poster', $user)
            ->where('series', $series)
            ->where('content', $content)
            ->first();
        
        // 投稿したファイルのパスを取得する
        $uuid = $content_object->path;
        // $file_list = glob(public_path('storage/'.$uuid.'/*.*'));
        $file_list_path = glob(storage_path('app/public/'.$uuid.'/*.*'));
        $file_list = [];
        foreach ($file_list_path as $path) {
            array_push($file_list, basename($path));
        }

        return view('home_content', compact('login_user', 'user', 'series', 'content', 'uuid', 'file_list'));
    }

    public function home_result(Request $request)
    {
        $login_user = \Auth::user();

        $param = [
            'category' => $request->category,
            'word' => $request->word,
        ];

        $category = $param['category'];
        $word = $param['word'];

        $list = Contents::where($category, $word)->get();

        return view('home_result', compact('login_user', 'category', 'word', 'list_result'));
    }
}
