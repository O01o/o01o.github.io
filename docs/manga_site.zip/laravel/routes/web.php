<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::redirect('/', '/home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'home_login_user']);
Route::get('/home/{user}', [App\Http\Controllers\HomeController::class, 'home_user']);
Route::get('/home/{user}/{series}', [App\Http\Controllers\HomeController::class, 'home_series']);
Route::get('/home/{user}/{series}/{content}', [App\Http\Controllers\HomeController::class, 'home_content']);

Route::get('/result', [App\Http\Controllers\HomeController::class, 'home_result']);

Route::get('/create', [App\Http\Controllers\CreateController::class, 'create']);
Route::post('/store', [App\Http\Controllers\CreateController::class, 'store']);
Route::post('/done', [App\Http\Controllers\CreateController::class, 'done']);