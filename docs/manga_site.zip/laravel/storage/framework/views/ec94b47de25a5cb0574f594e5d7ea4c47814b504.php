<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"><?php echo e($login_user['name']); ?> さんの新規投稿</div>
        <div class="card-body">
            <?php echo e($message); ?>

            <a class='d-block' href='/home'>ホームへ</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/done.blade.php ENDPATH**/ ?>