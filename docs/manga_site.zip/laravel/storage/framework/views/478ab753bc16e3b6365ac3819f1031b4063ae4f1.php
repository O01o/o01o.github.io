<?php $__env->startSection('content'); ?>

<div class="card h-100">
    <div class="card-header">検索結果(<?php echo e($category); ?>): <?php echo e($word); ?></div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            
            <?php if($list == NULL): ?>
                No Result
            <?php else: ?>
                <h2>検索結果一覧</h2>
                <?php if($category == 'poster'): ?>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/home/<?php echo e($element->poster); ?>"><?php echo e($element->poster); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($category == 'series'): ?>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/home/<?php echo e($element->poster); ?>/<?php echo e($element->series); ?>"><?php echo e($element->series); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($category == 'content'): ?>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/home/<?php echo e($element->poster); ?>/<?php echo e($element->series); ?>/<?php echo e($element->content); ?>"><?php echo e($element->content); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    恐らく条件が適切ではありません。
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/home_result.blade.php ENDPATH**/ ?>