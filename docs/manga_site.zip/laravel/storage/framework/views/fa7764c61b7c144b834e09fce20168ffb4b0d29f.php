<?php $__env->startSection('content'); ?>

<div class="card h-100">
    <div class="card-header"><?php echo e($user); ?> さんのページ</div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($list_series == NULL): ?>
                No Result
            <?php else: ?>
                <h2>投稿シリーズ</h2>
                <?php $__currentLoopData = $list_series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/home/<?php echo e($user); ?>/<?php echo e($series); ?>"><?php echo e($series); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/home_user.blade.php ENDPATH**/ ?>