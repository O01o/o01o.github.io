<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"> <?php echo e($login_user['name']); ?> さんの新規投稿 <?php echo e($message = ''); ?></div>
        <div class="card-body">
            <form method="POST" action="/store" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name='file[]' value="" multiple accept="image/*">
                <input type="text" name="series" cols="30" rows="10" placeholder="シリーズ名">
                <input type="text" name="content" cols="30" rows="10" placeholder="コンテンツ名">
                
                <button type="submit" class="btn bun-primary btn-lg">保存</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/create.blade.php ENDPATH**/ ?>