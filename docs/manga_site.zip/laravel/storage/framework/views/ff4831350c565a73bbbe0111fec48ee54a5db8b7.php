<?php $__env->startSection('content'); ?>

<div class="card h-100">
    <div class="card-header">シリーズ: <?php echo e($series); ?> （投稿者名: <?php echo e($user); ?>）</div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($list == NULL): ?>
                No Result
            <?php else: ?>
                <h2>投稿コンテンツ</h2>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/home/<?php echo e($user); ?>/<?php echo e($series); ?>/<?php echo e($element->content); ?>"><?php echo e($element->content); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/home_series.blade.php ENDPATH**/ ?>