<?php $__env->startSection('content'); ?>

<div class="card h-100">
    <div class="card-header">コンテンツ: <?php echo e($content); ?>（投稿者名: <?php echo e($user); ?>, シリーズ名: <?php echo e($series); ?></div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($file_list == NULL): ?>
                No Result
            <?php else: ?>
                <h2>投稿コンテンツ</h2>
                <?php $__currentLoopData = $file_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($file); ?><br>
                    <img src="<?php echo e(asset('storage/'.$uuid.'/'.$file)); ?>" height="400px"></a><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/home_content.blade.php ENDPATH**/ ?>