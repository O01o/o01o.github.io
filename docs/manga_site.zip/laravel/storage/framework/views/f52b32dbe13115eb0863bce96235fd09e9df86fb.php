<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="main">
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                  <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="row" style='height: 92vh;'>
                <div class="col-md-2 p-0">
                    <div class="card h-100">
                        <div class="card-header">ホーム</div>
                        <div class="card-body py-2 px-4">
                            <a class='d-block' href='/home'><?php echo e($login_user['name']); ?>さんのページへ</a>
                            <a class='d-block' href='/create'>新規投稿</a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2 p-0">
                    <div class="card h-100">
                        <div class="card-header d-flex">検索</div>
                        <div class="card-body p-2">
                            <form method="GET" action="/result" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="word" cols="30" rows="10" placeholder="検索・・・">
                                <div class="radio-button">
                                    <input type="radio" name="category" value="poster" checked>投稿者<br>
                                    <input type="radio" name="category" value="series">シリーズ名<br>
                                    <input type="radio" name="category" value="content">コンテンツ名<br>
                                </div>
                                <button type="submit" class="btn bun-primary btn-lg">検索</button>
                            </form>
                        </div>
                    </div>    
                </div> <!-- col-md-3 -->

                <div class="col-md-8 p-0">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            
            </div> <!-- row justify-content-center -->
        </main>
    </div>
    <?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>